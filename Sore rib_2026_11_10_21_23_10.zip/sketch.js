document.addEventListener('DOMContentLoaded', () => {
  const style = `
    :root {
      color-scheme: dark;
      --space: #080d1b;
      --hour: #ffca78;
      --minute: #75d9e8;
      --second: #ff8291;
    }

    * { box-sizing: border-box; }
    html, body { min-height: 100%; }

    body {
      margin: 0;
      display: grid;
      min-height: 100vh;
      place-items: center;
      overflow: hidden;
      background:
        radial-gradient(ellipse at 50% 45%, rgba(32, 54, 91, .42), transparent 55%),
        radial-gradient(ellipse at 50% 100%, #111a2d 0, var(--space) 65%);
      font-family: sans-serif;
    }

    .system {
      display: block;
      width: min(94vmin, 760px);
      height: min(94vmin, 760px);
      overflow: visible;
    }

    .orbit {
      fill: none;
      stroke-width: 1.4;
    }

    .orbit-hour { stroke: rgba(255, 202, 120, .25); }
    .orbit-minute { stroke: rgba(117, 217, 232, .24); }
    .orbit-second { stroke: rgba(255, 130, 145, .24); }

    .planet circle {
      stroke-width: 1.5;
      filter: drop-shadow(0 0 12px currentColor);
    }

    .planet text {
      fill: #101725;
      font-size: 21px;
      font-weight: 800;
      letter-spacing: -.7px;
      text-anchor: middle;
      dominant-baseline: central;
      font-variant-numeric: tabular-nums;
      pointer-events: none;
    }

    .planet-hour { color: var(--hour); }
    .planet-hour circle { fill: url(#hourSurface); stroke: #ffe0aa; }
    .planet-minute { color: var(--minute); }
    .planet-minute circle { fill: url(#minuteSurface); stroke: #b4f4f4; }
    .planet-second { color: var(--second); }
    .planet-second circle { fill: url(#secondSurface); stroke: #ffc0c6; }

    .star { fill: #e7efff; }

    @media (max-width: 480px) {
      .planet text { font-size: 19px; }
    }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after { scroll-behavior: auto !important; }
    }
  `;

  const svgMarkup = `
    <svg class="system" viewBox="0 0 760 760" role="img" aria-label="A live clock shown as three planets orbiting a sun">
      <defs>
        <radialGradient id="sunSurface" cx="35%" cy="30%">
          <stop offset="0" stop-color="#fff5bd" />
          <stop offset=".48" stop-color="#ffbf69" />
          <stop offset="1" stop-color="#f27847" />
        </radialGradient>
        <radialGradient id="hourSurface" cx="32%" cy="25%">
          <stop offset="0" stop-color="#fff1cb" />
          <stop offset="1" stop-color="#f2a94f" />
        </radialGradient>
        <radialGradient id="minuteSurface" cx="32%" cy="25%">
          <stop offset="0" stop-color="#e1ffff" />
          <stop offset="1" stop-color="#51b9d1" />
        </radialGradient>
        <radialGradient id="secondSurface" cx="32%" cy="25%">
          <stop offset="0" stop-color="#ffe4e4" />
          <stop offset="1" stop-color="#ec647d" />
        </radialGradient>
        <radialGradient id="sunGlow">
          <stop offset="0" stop-color="#ffbd68" stop-opacity=".24" />
          <stop offset="1" stop-color="#ffbd68" stop-opacity="0" />
        </radialGradient>
      </defs>

      <g aria-hidden="true">
        <circle class="star" cx="92" cy="124" r="1.7" opacity=".8" />
        <circle class="star" cx="192" cy="79" r="1.2" opacity=".55" />
        <circle class="star" cx="333" cy="112" r="1.5" opacity=".7" />
        <circle class="star" cx="588" cy="90" r="1.8" opacity=".62" />
        <circle class="star" cx="676" cy="186" r="1.2" opacity=".7" />
        <circle class="star" cx="82" cy="330" r="1.2" opacity=".5" />
        <circle class="star" cx="150" cy="587" r="1.6" opacity=".7" />
        <circle class="star" cx="265" cy="677" r="1.2" opacity=".55" />
        <circle class="star" cx="569" cy="653" r="1.5" opacity=".7" />
        <circle class="star" cx="695" cy="495" r="1.3" opacity=".55" />
        <circle class="star" cx="630" cy="316" r="1.1" opacity=".8" />
      </g>

      <g transform="translate(380 380)">
        <circle r="330" class="orbit orbit-second" />
        <circle r="245" class="orbit orbit-minute" />
        <circle r="160" class="orbit orbit-hour" />
        <circle r="116" fill="url(#sunGlow)" />
        <circle r="48" fill="url(#sunSurface)" />
        <circle r="54" fill="none" stroke="#ffd38b" stroke-opacity=".23" />
        <g class="planet planet-hour" id="hourPlanet">
          <circle r="34" />
          <text id="hourValue" y="1">12</text>
        </g>
        <g class="planet planet-minute" id="minutePlanet">
          <circle r="31" />
          <text id="minuteValue" y="1">00</text>
        </g>
        <g class="planet planet-second" id="secondPlanet">
          <circle r="29" />
          <text id="secondValue" y="1">00</text>
        </g>
      </g>
    </svg>
  `;

  document.body.insertAdjacentHTML('beforeend', `<style>${style}</style>${svgMarkup}`);

  const planets = [
    { group: document.getElementById('hourPlanet'), value: document.getElementById('hourValue'), radius: 160 },
    { group: document.getElementById('minutePlanet'), value: document.getElementById('minuteValue'), radius: 245 },
    { group: document.getElementById('secondPlanet'), value: document.getElementById('secondValue'), radius: 330 }
  ];

  function updateClock() {
    const now = new Date();
    const hours = now.getHours() % 12;
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const values = [
      String(hours || 12).padStart(2, '0'),
      String(minutes).padStart(2, '0'),
      String(seconds).padStart(2, '0')
    ];
    const turns = [hours / 12, minutes / 60, seconds / 60];

    planets.forEach((planet, index) => {
      const angle = turns[index] * Math.PI * 2 - Math.PI / 2;
      const x = Math.cos(angle) * planet.radius;
      const y = Math.sin(angle) * planet.radius;
      planet.group.setAttribute('transform', `translate(${x} ${y})`);
      planet.value.textContent = values[index];
    });
  }

  updateClock();
  window.setInterval(updateClock, 1000);
});
